
function split(text){
  return String(text).split(/(?<=[.!?])\s+/).filter(Boolean);
}

function cleanSentence(s){
  let t = s.toLowerCase();

  // remove questions
  if(/\?$/.test(t)){
    return "Gerçek burada.";
  }

  // simplify phrases
  if(/ikna süreci|içsel pazarlık|süreç|mekanizma/.test(t)){
    return "Kaçıyorsun.";
  }

  if(/neden|nasıl|sence/.test(t)){
    return "Gerçek burada.";
  }

  // shorten
  let words = s.split(" ").slice(0,6).join(" ");
  return words;
}

function applyFinalPolish(pkg){
  let parts = split(pkg.script || "");
  let out = [];

  for(let p of parts){
    let c = cleanSentence(p);
    if(c && c.length > 2){
      out.push(c);
    }
  }

  // ensure strong ending
  if(out.length > 0){
    out[out.length - 1] = "Başla.";
  }

  pkg.script = out.join(". ");
  pkg.finalPolishMeta = true;
  return pkg;
}

module.exports = { applyFinalPolish };
