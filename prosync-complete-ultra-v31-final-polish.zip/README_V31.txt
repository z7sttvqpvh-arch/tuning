V31 FINAL POLISH ENGINE

Purpose:
Final cleanup before upload.

Features:
- removes all questions
- simplifies abstract phrases
- enforces short sentences
- guarantees strong ending

Pipeline:
generate → V28 → V29 → V30 → V31 → upload
