// V26 Creator Mode Engine
function split(text){
  return String(text).split(/(?<=[.!?])\s+/).filter(Boolean);
}

function simplify(sentence){
  return sentence
    .replace(/beynin seni durdurma oyunu/gi,'beynin seni kandırıyor')
    .replace(/biyolojik/g,'')
    .replace(/açıklama/g,'')
    .trim();
}

function compress(text){
  return split(text).map(s=>{
    let words=s.split(' ');
    return words.slice(0,7).join(' ');
  }).join('. ');
}

function applyCreatorMode(pkg){
  let s=pkg.script||'';
  s=simplify(s);
  s=compress(s);
  pkg.script=s;
  return pkg;
}

module.exports={applyCreatorMode};
